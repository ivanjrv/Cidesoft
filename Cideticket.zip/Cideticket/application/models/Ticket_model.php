<?php 
class Ticket_model extends CI_Model {



        public function CreateTicket()
        {
        

          $data = array(
            'title' =>$this->input->post('title'),
            'description' => $this->input->post('description'),
            'department' => $this->input->post('department'),
            'subdepartment' => $this->input->post('subdepartment'),
            'priority' => $this->input->post('priority'),
            'status_id' =>1,
            'date' => mdate("%d/%m/%Y",time()));


           $query=$this->db->insert('ticket',$data);


           if($query){
                return true;
           }else{
                return false;
           }

                
        }





public function ShowTicket($buscar,$inicio = FALSE, $cantidadregistro = FALSE)
  {


          
          $this->db->like("title",$buscar);

    if($inicio !== FALSE && $cantidadregistro !== FALSE) {

      $this->db->limit($cantidadregistro,$inicio);


    }
     $this->db->order_by("id","desc");
    $query = $this->db->get("ticket");

    
       

      
return $query->result();
  }



public function  GetUpdate($id){



  $data=array("id"=>$id);
  $query=$this->db->where($data);
  $query=$this->db->get('ticket');

return $query;
      

  
}








public function  deleteTicket($id){



  $data=array("id"=>$id);
$query=$this->db->delete('ticket',$data);

return $query;
      

  
}


public function  GetDepartment(){


  $query=$this->db->get('department');

return $query;
      

  
}



        

}





<?php
class Login_model extends CI_model
{
    public function __construct()
    {
        $this->load->database();
    }
    public function login($user,$pass)
    {
     $query= $this->db->where('username =', $user);
       $query=  $this->db->or_where('email =', $user);
       $query=  $this->db->get('user'); 
        if($query->num_rows() == 1)
        {
            $row=$query->row();
            if($pass==$row->password)
            {
                $data=array('username'=>$row->username,'logged_in'=>true,'kind'=>$row->kind);
                $this->session->set_userdata($data);
                return true;
            }
        }
        
        return false;
    }
 }

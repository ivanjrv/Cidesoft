<?php
class Login extends CI_controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->load->model('Login_model');
      
    }
    public function index()
    {
    	if (isset($this->session->logged_in)) {
               redirect("client_user");
    		
    	}else{

$this ->form_validation->set_rules('user','Usuario','required',array('required'=>'Debe ingresar una %s.')); 


 $this ->form_validation -> set_rules ('pass' ,'Contraseña','required',array('required'=>'Debe ingresar una %s.')); 
               

                if  ( $this->form_validation->run ()  ==  false ) 
                { 
                        
                      $this->load->view("login/head");
                      $this->load->view("login/content");

                    
                } 
                else 
                { 
                	$user=$this->input->post("user");
                	$pass=$this->input->post("pass");

                	if($this->Login_model->login($user,$pass)==true){
                       
                       redirect("client_user");

                        


                	}else{

                		 $data["error"]="Usuario o Contraseña incorrecta";

                         $this->load->view("login/head");
                		 $this->load->view("login/content",$data);


                	}
                	
                 
                       
                } 
        
    }
    	}



 public function logged_out(){


    $this->session->sess_destroy();
    redirect("Login");


 }





    
   
}


<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_user extends CI_Controller {

	public function __construct(){
     
   parent::__construct();

   $this->load->model("Ticket_model");

		
	}


	public function index()
	{
		$this->load->view('client/head');
		$this->load->view('client/content');
		

		$query=$this->Ticket_model->GetDepartment();

         $data["department"] = $query->result_array();
         $this->load->view('modal/create_ticket',$data);
         $this->load->view('client/footer');

	}




	public function chat($mensage=null)
	{
		$this->load->view('client/head');
		$this->load->view('client/content_chat');
		$this->load->view('client/footer');
	}


}

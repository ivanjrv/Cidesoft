<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticket extends CI_Controller {


	public function __construct(){
     
   parent::__construct();

   $this->load->model("Ticket_model");

		
	}


  public  function CreateTicket(){


  $this->Ticket_model->CreateTicket();




}


public function ShowTicket()
	{	
				
		
	 //valor a Buscar
	    $buscar = $this->input->post("search");
		$numeropagina = $this->input->post("nropagina");
		$cantidad = $this->input->post("cantidad");
		$inicio = ($numeropagina -1)*$cantidad;

		
			$data = array(
			"data" => $this->Ticket_model->ShowTicket($buscar,$inicio,$cantidad),
		     "totalregistros" => count($this->Ticket_model->ShowTicket($buscar)),
			  "cantidad" =>$cantidad);

		
		echo json_encode($data);
		
	}



	 public function DeleteTicket(){

    $id = $this->input->post("id");

  $html=array();


$query=$this->Ticket_model->deleteTicket($id);

if ($query){

$html["vali_form"]="true";
$html["mensage"]="Ticket Eliminado con Exito";

  

}else{

  $html["vali_form"]="false";
$html["mensage"]="Problemas";

}






echo  json_encode($html);


 }


  public function GetUpdate(){

   $id = $this->input->post("id");

  $html=array();


$query=$this->Ticket_model->GetUpdate($id);
$row = $query->row();

        

 echo json_encode($row);
  




  
}


public function GetDepartment(){




$query=$this->Ticket_model->GetDepartment();

$data["department"] = $query->result_array();



   

}




}

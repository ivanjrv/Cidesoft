
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
           <?=form_open('login'); ?>
              <h1>Iniciar Sesion</h1>
              <div>
                <input type="text" class="form-control" placeholder="Usuario" name="user"  value="<?=set_value('user') ?>" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="contraseña" name="pass" />
              </div>
              <div>
                <button class="btn btn-default submit"">Entrar</button>
                <a class="reset_pass" href="#">Olvidaste tu contraseña?</a>
              </div>
                 <?=form_close();?>
            <div class="col-md-12 offset-md-3">

  <?=validation_errors("<div class='alert alert-danger alert-dismissible fade in' role='alert'>
                    <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>×</span>
                    </button>"," 
                  </div>");?>
     
     <?php  

     if (isset($error)) {
      ?>

       
<div class="alert alert-danger alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                    </button>
                    <small> <?=$error; ?></small> 
                  </div>

       <?php

     }

      ?>

    </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="#signup" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-paw"></i>CideTicket!</h1>
                  <p>© Derechos Reservados por Cidesoft .</p>
                </div>
              </div>
          
          </div>
        </div>

  
          </section>
        </div>
      </div>
    </div>
  </body>
</html>
     <!-- jQuery -->
    <script src="<?=base_url();?>template/js/jquery.min.js"></script>

     <!-- Bootstrap -->
    <script src="<?=base_url();?>template/js/bootstrap.min.js"></script>
    <!-- bootstrap-wysiwyg -->
    <script src="<?=base_url();?>template/js/bootstrap-wysiwyg.min.js"></script>
    <script src="<?=base_url();?>template/js/jquery.hotkeys.js"></script>
    <script src="<?=base_url();?>template/js/prettify.js"></script>
    <!-- jQuery Tags Input -->
  
    <!-- Custom Theme Scripts -->
    <script src="<?=base_url();?>template/js/custom.min.js"></script>
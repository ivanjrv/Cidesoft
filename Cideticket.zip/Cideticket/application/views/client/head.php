<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Cideticket! | </title>

    <!-- Bootstrap -->
    <link href="<?=base_url();?>template/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?=base_url();?>template/css/fonts/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->


    <!-- Custom Theme Style -->
    <link href="<?=base_url();?>template/css/custom.min.css" rel="stylesheet">
     <link href="<?=base_url();?>template/css/jquery.dataTables.css" rel="stylesheet">
  </head>

  <body class="nav-md">
  
        


  <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.html" class="site_title"><i class="fa fa-paw"></i> <span>Cideticket!</span></a>
            </div>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?=base_url();?>template/images/img.jpg" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Bienvenido,</span>
                <h2>Oscar Agallo</h2>
              </div>
            </div>
            <!-- /menu profile quick info -->

            <br />

            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
          <li><a href="<?=base_url()?>client_user" ><i class="fa fa-ticket"></i> Tickets </a></li>
    

                 <!-- <li><a><i class="fa fa-edit"></i> Forms <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="form.html">General Form</a></li>
                      <li><a href="form_advanced.html">Advanced Components</a></li>
                      <li><a href="form_validation.html">Form Validation</a></li>
                      <li><a href="form_wizards.html">Form Wizard</a></li>
                      <li><a href="form_upload.html">Form Upload</a></li>
                      <li><a href="form_buttons.html">Form Buttons</a></li>
                    </ul>
                  </li>-->
             
              </div>
              

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
        
            <!-- /menu footer buttons -->
          </div>
        </div>

        <!-- top navigation -->
        <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?=base_url();?>template/images/img.jpg" alt="">Oscar Agallo
                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="javascript:;"> Perfil</a></li>
                    
                    <li><a href="javascript:;">Ayuda</a></li>
                    <li><a href="<?=base_url()?>Login/logged_out"><i class="fa fa-sign-out pull-right"></i>Cerrar Sesion</a></li>
                  </ul>
                </li>

                <li role="presentation" class="dropdown">
                  <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-envelope-o"></i>
                    <span class="badge bg-green">1</span>
                  </a>
                  <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <a>
                        <span class="image"><img src="images/img.jpg" alt="Profile Image" /></span>
                        <span>
                          <span>John Smith</span>
                          <span class="time">3 mins ago</span>
                        </span>
                        <span class="message">
                          Film festivals used to be do-or-die moments for movie makers. They were where...
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="text-center">
                        <a>
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
                  </ul>
                </li>
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="row top_tiles">
              <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-send"></i></div>
                  <div class="count">2</div>
                  <h3>Abierto</h3>
                 
                </div>
              </div>
             
              <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-sort-amount-desc"></i></div>
                  <div class="count">3</div>
                  <h3>Pendientes</h3>
                 
                </div>
              </div>
              <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-check-square-o"></i></div>
                  <div class="count">5</div>
                  <h3>Atendidos</h3>
                 
                </div>
              </div>
               <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="tile-stats">
                  <div class="icon"><i class="fa fa-comments-o"></i></div>
                  <div class="count">2</div>
                  <h3>Cerrado</h3>
                 
                </div>
              </div>
            </div>

 

            <div class="row">
            <div class="x_panel">
                  <div class="x_title">
                    <h2>Gestion de tickets </h2>
                    <div class="title_right">

                      <div class="col-md-4">
                      
                       <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".modal_create"><i class="fa fa-plus-square"></i>
  Nuevo Tickets</button>
                      </div>

                      <div class="col-md-2">
                        <select class="form-control" id="cant">
                            <option value="5">5</option>
                            <option value="10">10</option>
                            
                            
                          </select>
                      </div>




                <div class="col-md-4 col-sm-4 col-xs-10 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Buscar..." id="search" >
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button"><i class="fa fa-search" ></i></button>
                    </span>
                  </div>
                </div>
                        <!-- modals -->
                  <!-- Large modal -->
                 


                 




                  
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">


                
                    <div class="table-responsive">
                      <table class="table bulk_action" id="table_ticket">
                        <thead>
                         
             
                            <th class="column-title" style="display: table-cell;">Titulo </th>
                            <th class="column-title" style="display: table-cell;">Departamento </th>
                            <th class="column-title" style="display: table-cell;">Area </th>
                            <th class="column-title" style="display: table-cell;">Prioridad </th>
                            <th class="column-title" style="display: table-cell;">Estado </th>
                            <th class="column-title" style="display: table-cell;">Fecha </th>
                            <th class="column-title no-link last" style="display: table-cell;"><span class="nobr">Opcion</span>
                            </th>
                            <th class="bulk-actions" colspan="7" style="display: none;">
                              <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt">1 Records Selected</span> ) <i class="fa fa-chevron-down"></i></a>
                            </th>
                          </tr>
                        </thead>

                        <tbody id="result_ticket">
                        

                        
                       
                        </tbody>
                      </table>

                      <div class="col-md-4 col-md-offset-8" id="pagi"></div>
                    </div>
              
            
                  </div>
                </div>

            </div>



           



       
            </div>
          </div>
        </div>
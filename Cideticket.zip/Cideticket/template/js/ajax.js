$(function(){

   ShowTicket();
   CreateTicket();





 });
function CreateTicket(){


$("#submit_ticket").click(function(e){


var title=$("#title").val();
var department=$("#department").val();
var subdepartment=$("#subdepartment").val();
var priority=$("#priority").val();
var description=$("#editor-one").html();






   
  $.ajax({
    url :'Ticket/CreateTicket',
    type: "POST",
    data:{title:title,
          department:department,
          subdepartment:subdepartment,
          priority:priority,
          description:description
          },
    dataType:"html",
    beforeSend:function(){
      
    },
    success:function(response){


alert("Ticket Creado con Exito");
 $(".modal_create").modal('hide');
  $('#form_ticket')[0].reset();
  $('#editor-one').html("");
 mostrarDatos("",1,5);


     }


   });





});

e.preventDefault();

}


function ShowTicket(){



mostrarDatos("",1,5);


  
  $("#search").keyup(function(){
    textobuscar = $("#search").val();
    valoroption = $("#cant").val();
    mostrarDatos(textobuscar,1,valoroption);

  });



  


  $("body").on("click","#pagi li a",function(e){
    e.preventDefault();
    valorhref = $(this).attr("href");
    valorBuscar = $("#search").val();
    valoroption = $("#cant").val();

    alert(valorhref);

    mostrarDatos(valorBuscar,valorhref,valoroption);
  });

 /* $("#cant").change(function(){
    valoroption = $(this).val();
    valorBuscar = $("#search").val();
mostrarDatos(valorBuscar,1,valoroption);

  });
*/




}

function deleteTicket(){
  $('.delete').click(function(e){

id = $(this).attr('href');


 var opcion = confirm('Seguro desea Eliminar este Ticket ?');
    if (opcion == true) {
        

        load(id,'Ticket/DeleteTicket');

          alert("Ticket Eliminado con Exito!");
        mostrarDatos("",1,5);




         
 } else {
    
    return false;}
 

e.preventDefault();


});
}


function GetUpdate(){

  $(".GetUdapte").click(function(e){
    
    id=$(this).attr("href");



 $.ajax({
    url:"http://localhost/Cideticket/Ticket/GetUpdate",
    type: "POST",
    data: {id:id},
    dataType:"html",
    beforeSend:function(){


    },
    success:function(response){
     
     var json=JSON.parse(response);

     $("#title_udpate").val(json.title);
     $("#tempde").val(json.department);
      $("#subdepartment_udpate").append("<option value='"+json.subdepartment+"'>"+json.subdepartment+"</option>");
     $("#edit_udpate").html(json.description);


       $('.modal_update').modal({
            show:true,
            backdrop:'static'
          });


    

    
}});
 









    e.preventDefault();
  });
  


}





function load(id,page){
  
  $.ajax({
    url:"http://localhost/Cideticket/"+page,
    type: "POST",
    data: {id:id},
    dataType:"JSON",
    beforeSend:function(){


    },
    success:function(response){
      var json=JSON.parse(response);

      if(json.vali_form=="true"){




   }else{

    

      alert(json.mensage);

     
       


   }

    
}});

}





function mostrarDatos(valorBuscar,pagina,cantidad){
  $.ajax({
    url :"http://localhost/Cideticket/Ticket/ShowTicket",
    type: "POST",
    data: {search:valorBuscar,nropagina:pagina,cantidad:cantidad},
    dataType:"json",
    beforeSend:function(){

      $("#result").html("<img class='offset-md-5' src='recursos/img/loader.gif' alt='' />");
    },
    success:function(response){



      
      html = "";
  

      if (response.totalregistros>0){

         $.each(response.data,function(key,item){
html+="<tr>"+
"<td><a href='http://localhost/Cideticket/client_user/chat' class='btn btn-link'>"+item.title+"</a></td>"+
"<td>"+item.department+"</td>"+
"<td>"+item.subdepartment+"</td>";


if(item.priority==1){
  html+="<td><button type='button' class='btn btn-round btn-danger btn-xs'>Critica</button></td>";
}
if(item.priority==2){
  html+="<td><button type='button' class='btn btn-round btn-warning btn-xs'>Alta</button></td>";
}
if(item.priority==3){
  html+="<td><button type='button' class='btn btn-round btn-success btn-xs'>Media</button></td>";
}

if(item.priority==4){
  html+="<td><button type='button' class='btn btn-round btn-success btn-xs'>Baja</button></td>";
}

if(item.status_id==1){
  html+="<td><button type='button' class='btn btn-round btn-success btn-xs'>Pendiente</button></td>";
}

if(item.status_id==2){
  html+="<td><button type='button' class='btn btn-round btn-warning btn-xs'>Cerrado</button></td>";
}

if(item.status_id==3){
  html+="<td><button type='button' class='btn btn-round btn-inf btn-xs'>Pendiente</button></td>";
}

 html+="<td>"+item.date+"</td>"+
 "<td>"+
"<a href='#' class='btn btn-primary btn-xs'><i class='fa fa-ticket'></i>Ver Ticket</a>"+
"<a href='"+item.id+"' class='GetUdapte btn btn-info btn-xs'><i class='fa fa-pencil'></i>Editar</a>"+
"<a href='"+item.id+"' class='btn btn-danger btn-xs delete'><i class='fa fa-trash-o'></i>Eliminar</a>"+

"</td>";

  html+="</tr>";


});

html+="<script type='text/javascript'>"+
              "deleteTicket();"+
                "GetUpdate();"+
            "</script> ";

       
   

     }else{
       html+="<tr>"+
              
    "<td ><h3> Ticket "+valorBuscar+" no encuentrado...</h3></td></tr>";
     }




 $("#result_ticket").html(html);

     linkseleccionado = Number(pagina);
      //total registros
      totalregistros = response.totalregistros;
      //cantidad de registros por pagina
      cantidadregistros = response.cantidad;

      numerolinks = Math.ceil(totalregistros/cantidadregistros);
      paginador = "<ul class='pagination pagination-md justify-content-center'>";

      if(linkseleccionado>1)
      {
        paginador+="<li class='page-item'><a href='1' class='page-link'>&laquo;</a></li>";
        paginador+="<li class='page-item'><a href='"+(linkseleccionado-1)+"' class='page-link'>&lsaquo;</a></li>";

      }
      else
      {
        paginador+="<li class='disabled page-item'><a class='page-link' href='#'>&laquo;</a></li>";
        paginador+="<li class='disabled page-item '><a class='page-link' href='#'>&lsaquo;</a></li>";
      }
      //muestro de los enlaces 
      //cantidad de link hacia atras y adelante
      cant = 2;
      //inicio de donde se va a mostrar los links
      pagInicio = (linkseleccionado > cant) ? (linkseleccionado - cant) : 1;
      //condicion en la cual establecemos el fin de los links
      if (numerolinks > cant)
      {
        //conocer los links que hay entre el seleccionado y el final
        pagRestantes = numerolinks - linkseleccionado;
        //defino el fin de los links
        pagFin = (pagRestantes > cant) ? (linkseleccionado + cant) :numerolinks;
      }
      else 
      {
        pagFin = numerolinks;
      }

      for (var i = pagInicio; i <= pagFin; i++) {
        if (i == linkseleccionado)
          paginador +="<li class='page-item active'><a class='page-link' href='"+i+"'>"+i+"</a></li>";
        else
          paginador +="<li class='page-item'><a class='page-link' href='"+i+"'>"+i+"</a></li>";
      }
      //condicion para mostrar el boton sigueinte y ultimo
      if(linkseleccionado<numerolinks)
      {
        paginador+="<li class='page-item' ><a href='"+(linkseleccionado+1)+"' class='page-link'>&rsaquo;</a></li>";
        paginador+="<li class='page-item' ><a  href='"+numerolinks+"' class='page-link'>&raquo;</a></li>";

      }
      else
      {
        paginador+="<li class='page-item disabled'><a href='#' class='page-link'>&rsaquo;</a></li>";
        paginador+="<li class='page-item disabled'><a href='#' class='page-link'>&raquo;</a></li>";
      }
      
      paginador +="</ul>";
      $("#pagi").html(paginador);
    
      

    }
  });




}





